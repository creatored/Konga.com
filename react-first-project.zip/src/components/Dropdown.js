import React, { useState } from 'react';
import { MdKeyboardArrowDown } from "react-icons/md";
function Dropdown() {
  const [isShown, setIsShown] = useState(false);

  return (
    <div className="Dropdown"
      onMouseEnter={() => setIsShown(true)}
      onMouseLeave={() => setIsShown(false)}>
      <a
        className='help'>
        Help
        <MdKeyboardArrowDown className='help-icon' />
      </a>
      {isShown && (
        <div className='dropdown-content'>
          <p>FAQs</p>
          <p>Contact Us</p>
          <p>Track My Order</p>
          <p>Konga Return Policy</p>
        </div>
      )}
    </div>
  );
}

export default Dropdown;