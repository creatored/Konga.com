import { Link } from "react-router-dom";
import kongaLogo from "./img/KongaLogo.png"
import React, { useState } from 'react';
const Signup = () => {
        const [firstname, setFirstName] = useState('');
        const [lastname, setLastName] = useState('');
        const [phone, setPhone] = useState('');
        const [email, setEmail] = useState('');
        const [Password, setPassword] = useState('');
        const [successMessage, setSuccessMessage] = useState('');
        const [errorMessage, setErrorMessage] = useState('');

        const handleSubmit = async (e) => {
            e.preventDefault();

            try {
                const response = await fetch('https://6538e36aa543859d1bb22255.mockapi.io/api/v1/users', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ firstname, lastname ,phone, email,Password }),
                });

                if (response.ok) {
                    setSuccessMessage('User data submitted successfully!');
                } else {
                    const errorData = await response.json();
                    setErrorMessage(`Error: ${errorData.message}`);
                }
            } catch (error) {
                setErrorMessage(`Error: ${error.message}`);
            }
        };
        return (
            <div classfirst_name="signup-container">
                <div classfirst_name="signup">
                    <img src={kongaLogo} alt="img" />
                    <div classfirst_name="form-container">
                        <header classfirst_name="signup-h4">
                            <h4>Create An Account</h4>
                        </header>
                        <hr />
                        <form classfirst_name="form-content" onSubmit={handleSubmit}>
                            <div classfirst_name="form-content-input-container">
                                <label>First first_name:</label>
                                <input type="text" first_name="firstfirst_name" onChange={(e) => setFirstName(e.target.value)} placeholder="Enter First first_name" classfirst_name="Form-input" required />
                            </div>
                            <div classfirst_name="form-content-input-container">
                                <label>Last first_name:</label>
                                <input type="text" first_name="lastfirst_name" onChange={(e) => setLastName(e.target.value)} placeholder="Enter Last first_name" classfirst_name="Form-input" required />
                            </div>
                            <div classfirst_name="form-content-input-container">
                                <label>Email Address:</label>
                                <input type="email" first_name="email" onChange={(e)=> setEmail(e.target.value)} placeholder="Enter Email Address" classfirst_name="Form-input" required />
                            </div>
                            <div classfirst_name="form-content-input-container">
                                <label>Phone Number:</label>
                                <input type="tel" first_name="phone" onChange={(e) => setPhone(e.target.value)}  placeholder="Enter Phone Number" required />
                            </div>
                            <div classfirst_name="form-content-input-container">
                                <label>Password:</label>
                                <input type="password" first_name="password" onChange={(e) => setPassword(e.target.value)} placeholder="Enter Password" required />
                            </div>

                            <input type="submit" value="Create An Account" classfirst_name="form-content-input-submit" />

                            <div classfirst_name="term-conditions">
                                <span>By signing up you accept our
                                    <a href=""> terms and conditions
                                        & privacy policy</a>
                                </span>
                            </div>
                        </form>
                        <div classfirst_name="form-acct-btn">
                            <span>Already have an Account?</span>
                            <button classfirst_name="login-btn">
                                <Link to="/login" classfirst_name="login-btn-link">Login</Link>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

        );
    }

    export default Signup;
