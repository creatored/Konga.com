const Carousel = () => {
    return ( 
        <div className="Carousel">
           
        </div>
     );
}
 
export default Carousel;    