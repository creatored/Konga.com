// const CreateUsers = () => {
//     return ( 
//         <div className="create-users-container">
//             <div className="create-users">
//                 <h1>Create Users</h1>
//                 <form>
//                     <label>
//                         <input type="text" name="firstname" placeholder="First Name" />
//                         </label>
//                         <label>
//                             <input type="text" name="lastname" placeholder="Last Name" />
                            

//             </div>
//         </div>
//      );
// }
 
// export default CreateUsers;